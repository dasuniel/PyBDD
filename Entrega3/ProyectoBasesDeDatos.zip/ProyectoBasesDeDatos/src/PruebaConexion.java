import java.sql.Connection;
import database.ConexionBD;

public class PruebaConexion {
    public static void main(String[] args) {
        Connection conn = ConexionBD.getConnection();
        if (conn != null) {
            System.out.println("¡Conexión establecida exitosamente!");
            try {
                conn.close();
                System.out.println("Conexión cerrada correctamente.");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("No se pudo establecer la conexión.");
        }
    }
}
