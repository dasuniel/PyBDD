package ui;

import service.GrupoService;
import service.UsuarioService;
import service.FacturaService;
import service.TransaccionService;

import java.util.Scanner;

public class Menu {
    private final GrupoService grupoService;
    private final FacturaService facturaService;
    private final TransaccionService transaccionService;
    private final UsuarioService usuarioService;
    private final Scanner scanner;

    public Menu(GrupoService grupoService, FacturaService facturaService, TransaccionService transaccionService, UsuarioService usuarioService) {
        this.grupoService = grupoService;
        this.facturaService = facturaService;
        this.transaccionService = transaccionService;
        this.usuarioService = usuarioService;
        this.scanner = new Scanner(System.in);

        if (realizarLogin()) {
            mostrarMenuPrincipal();
        } else {
            System.out.println("Saliendo del sistema. No se pudo iniciar sesión.");
        }
    }

    private boolean realizarLogin() {
        System.out.println("--- Inicio de Sesión ---");
        boolean loginExitoso = false;

        while (!loginExitoso) {
            System.out.print("Correo: ");
            String correo = scanner.nextLine();
            System.out.print("Contraseña: ");
            String contrasena = scanner.nextLine();

            loginExitoso = usuarioService.login(correo, contrasena);
            if (!loginExitoso) {
                System.out.println("Credenciales incorrectas. Intenta de nuevo o escribe 'salir' para salir.");
                System.out.print("¿Quieres intentar de nuevo? (s/n): ");
                String respuesta = scanner.nextLine();
                if (respuesta.equalsIgnoreCase("n")) {
                    return false;
                }
            }
        }
        System.out.println("Inicio de sesión exitoso.");
        return true;
    }


    public void mostrarMenuPrincipal() {
        int opcion;
        do {
            System.out.println("\n--- Menú Principal ---");
            System.out.println("1. Crear Grupo");
            System.out.println("2. Ver Grupos");
            System.out.println("3. Registrar Usuario");
            System.out.println("4. Ver Usuarios");
            System.out.println("5. Crear Factura");
            System.out.println("6. Ver Facturas de un Grupo");
            System.out.println("7. Registrar Transacción");
            System.out.println("0. Salir");
            System.out.print("Selecciona una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer

            switch (opcion) {
                case 1 -> crearGrupo();
                case 2 -> verGrupos();
                case 3 -> registrarUsuario();
                case 4 -> verUsuarios();
                case 5 -> crearFactura();
                case 6 -> verFacturasDeGrupo();
                case 7 -> registrarTransaccion();
                case 0 -> System.out.println("Saliendo...");
                default -> System.out.println("Opción no válida. Inténtalo de nuevo.");
            }
        } while (opcion != 0);
    }

    private void crearGrupo() {
        System.out.print("Ingrese el nombre del grupo: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese la descripción del grupo: ");
        String descripcion = scanner.nextLine();

        boolean resultado = grupoService.crearGrupo(nombre, descripcion);
        System.out.println(resultado ? "Grupo creado exitosamente." : "Error al crear el grupo.");
    }

    private void verGrupos() {
        System.out.println("\n--- Listado de Grupos ---");
        grupoService.obtenerNombresGrupos().forEach(System.out::println);
    }

    private void registrarUsuario() {
        System.out.print("Ingrese el nombre del usuario: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese el correo del usuario: ");
        String correo = scanner.nextLine();
        System.out.print("Ingrese el teléfono del usuario: ");
        String telefono = scanner.nextLine();
        System.out.print("Ingrese el ID de PayPal del usuario: ");
        String paypalId = scanner.nextLine();
        System.out.print("Ingrese la contraseña del usuario: ");
        String contrasena = scanner.nextLine();
        System.out.print("Ingrese la URL de la imagen del usuario: ");
        String imagenUrl = scanner.nextLine();

        boolean resultado = usuarioService.registrarUsuario(nombre, correo, telefono, paypalId, contrasena, imagenUrl);
        System.out.println(resultado ? "Usuario registrado exitosamente." : "Error al registrar el usuario.");
    }

    private void verUsuarios() {
        System.out.println("\n--- Listado de Usuarios ---");
        usuarioService.obtenerUsuarios().forEach(System.out::println);
    }

    private void crearFactura() {
        System.out.print("Ingrese el ID del grupo: ");
        int grupoId = scanner.nextInt();
        System.out.print("Ingrese el ID del usuario creador: ");
        int usuarioCreadorId = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer

        System.out.print("Ingrese el título de la factura: ");
        String titulo = scanner.nextLine();
        System.out.print("Ingrese el monto de la factura: ");
        double monto = scanner.nextDouble();
        scanner.nextLine(); // Limpiar el buffer

        System.out.print("Ingrese el Url de la factura: ");
        String imagenUrl = scanner.nextLine(); // Capturar como String sin conversión

        facturaService.crearFactura(grupoId, usuarioCreadorId, titulo, monto, imagenUrl);

        System.out.println("Factura creada exitosamente.");
    }


    private void verFacturasDeGrupo() {
        System.out.print("Ingrese el ID del grupo: ");
        int grupoId = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer
        System.out.println("\n--- Facturas del Grupo ---");
        facturaService.obtenerFacturasPorGrupo(grupoId).forEach(System.out::println);
    }

    private void registrarTransaccion() {
        System.out.print("Ingrese el ID de la factura: ");
        int facturaId = scanner.nextInt();
        System.out.print("Ingrese el ID del usuario deudor: ");
        int deudorId = scanner.nextInt();
        System.out.print("Ingrese el ID del usuario acreedor: ");
        int acreedorId = scanner.nextInt();
        System.out.print("Ingrese el monto de la transacción: ");
        double monto = scanner.nextDouble();
        scanner.nextLine(); // Limpiar el buffer
        System.out.print("Ingrese el medio de pago: ");
        String medioPago = scanner.nextLine();
        System.out.print("Ingrese el estado de la transacción: ");
        String estado = scanner.nextLine();
        System.out.print("Ingrese el ID del aprobador: ");
        int aprobadorId = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer

        boolean resultado = transaccionService.registrarTransaccion(facturaId, deudorId, acreedorId, monto, medioPago, estado, aprobadorId);
        System.out.println(resultado ? "Transacción registrada exitosamente." : "Error al registrar la transacción.");
    }

    public void registrarFacturaConConfirmacion() {
        System.out.println("Ingrese el ID del grupo:");
        int grupoId = scanner.nextInt();
        System.out.println("Ingrese el ID del usuario creador:");
        int usuarioCreadorId = scanner.nextInt();
        scanner.nextLine(); // Consumir la nueva línea
        System.out.println("Ingrese el título de la factura:");
        String titulo = scanner.nextLine();
        System.out.println("Ingrese el monto de la factura:");
        double monto = scanner.nextDouble();
        scanner.nextLine(); // Consumir la nueva línea
        System.out.println("Ingrese la URL de la imagen de la factura:");
        String imagenUrl = scanner.nextLine();

        // Confirmación antes de guardar
        System.out.println("¿Desea guardar esta factura? (s/n)");
        String confirmacion = scanner.nextLine();
        if (confirmacion.equalsIgnoreCase("s")) {
            facturaService.crearFactura(grupoId, usuarioCreadorId, titulo, monto, imagenUrl);
        } else {
            System.out.println("La factura no fue guardada.");
        }
    }

}

