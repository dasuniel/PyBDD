package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {
    private final Connection connection;

    public UsuarioDAO(Connection connection) {
        this.connection = connection;
    }

    // Método para verificar las credenciales del usuario
    public boolean verificarCredenciales(String correo, String contrasena) {
        String query = "SELECT COUNT(*) AS total FROM Usuarios WHERE correo = ? AND contrasena = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, correo);
            stmt.setString(2, contrasena);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("total") > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error al verificar credenciales: " + e.getMessage());
        }
        return false;
    }

    // Obtener todos los usuarios registrados
    public List<String> obtenerUsuarios() {
        List<String> usuarios = new ArrayList<>();
        String query = "SELECT usuario_id, nombre FROM Usuarios";

        try (PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String usuarioInfo = String.format("ID: %d - %s",
                        rs.getInt("usuario_id"), rs.getString("nombre"));
                usuarios.add(usuarioInfo);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener usuarios: " + e.getMessage());
        }

        return usuarios;
    }

    public boolean actualizarCorreoUsuario(int usuarioId, String nuevoCorreo) {
        String query = "UPDATE Usuarios SET correo = ? WHERE usuario_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, nuevoCorreo);
            stmt.setInt(2, usuarioId);
            int filasActualizadas = stmt.executeUpdate();
            return filasActualizadas > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar el correo del usuario: " + e.getMessage());
            return false;
        }
    }

    public String obtenerImagenUsuario(int usuarioId) {
        String query = "SELECT imagen_url FROM Usuarios WHERE usuario_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, usuarioId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("imagen_url");
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener la imagen del usuario: " + e.getMessage());
        }
        return null;
    }



    // Obtener usuarios por grupo específico
    public List<String> obtenerUsuariosPorGrupo(int grupoId) {
        List<String> usuarios = new ArrayList<>();
        String query = """
            SELECT u.usuario_id, u.nombre 
            FROM Usuarios u
            JOIN Usuarios_Grupos ug ON u.usuario_id = ug.usuario_id
            WHERE ug.grupo_id = ?
        """;

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, grupoId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String usuarioInfo = String.format("ID: %d - %s",
                        rs.getInt("usuario_id"), rs.getString("nombre"));
                usuarios.add(usuarioInfo);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener usuarios por grupo: " + e.getMessage());
        }

        return usuarios;
    }

    // Registrar un nuevo usuario en la base de datos
    public void registrarUsuario(String nombre, String correo, String telefono,
                                 String paypalId, String contrasena, String imagenUrl) {
        String query = """
            INSERT INTO Usuarios (usuario_id, nombre, correo, telefono, paypal_id, 
                                  contrasena, ultimo_acceso, imagen_url) 
            VALUES (usuarios_seq.NEXTVAL, ?, ?, ?, ?, ?, SYSDATE, ?)
        """;

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, nombre);
            stmt.setString(2, correo);
            stmt.setString(3, telefono);
            stmt.setString(4, paypalId);
            stmt.setString(5, contrasena);
            stmt.setString(6, imagenUrl);

            stmt.executeUpdate();
            System.out.println("Usuario registrado exitosamente.");
        } catch (SQLException e) {
            System.err.println("Error al registrar usuario: " + e.getMessage());
        }
    }
}
