package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GrupoDAO {
    private final Connection connection;

    public GrupoDAO(Connection connection) {
        this.connection = connection;
    }

    public List<String> obtenerNombresGrupos() {
        List<String> nombresGrupos = new ArrayList<>();
        String query = "SELECT nombre FROM Grupos";

        try (PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                nombresGrupos.add(rs.getString("nombre"));
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener nombres de grupos: " + e.getMessage());
        }
        return nombresGrupos;
    }

    public void crearGrupo(String nombre, String descripcion) {
        String query = """
            INSERT INTO Grupos (grupo_id, nombre, descripcion, fecha_creacion) 
            VALUES (grupos_seq.NEXTVAL, ?, ?, SYSDATE)
        """;

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, nombre);
            stmt.setString(2, descripcion);
            stmt.executeUpdate();
            System.out.println("Grupo creado exitosamente.");
        } catch (SQLException e) {
            System.err.println("Error al crear el grupo: " + e.getMessage());
        }
    }
}
