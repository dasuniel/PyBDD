package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FacturaDAO {
    private final Connection connection;

    public FacturaDAO(Connection connection) {
        this.connection = connection;
    }

    public void crearFactura(int grupoId, int usuarioCreadorId, String titulo, double monto, String imagenUrl) {
        String query = """
        INSERT INTO Facturas (factura_id, grupo_id, usuario_creador_id, titulo, monto, fecha_creacion, imagenUrl) 
        VALUES (facturas_seq.NEXTVAL, ?, ?, ?, ?, SYSDATE, ?)
    """;

        try {
            connection.setAutoCommit(false); // Iniciar transacción

            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                stmt.setInt(1, grupoId);
                stmt.setInt(2, usuarioCreadorId);
                stmt.setString(3, titulo);
                stmt.setDouble(4, monto);
                stmt.setString(5, imagenUrl);

                stmt.executeUpdate();
                connection.commit(); // Confirmar transacción
                System.out.println("Factura creada exitosamente.");
            } catch (SQLException e) {
                connection.rollback(); // Revertir la transacción en caso de error
                System.err.println("Error al crear la factura: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Error en la transacción: " + e.getMessage());
        }
    }





    public List<String> obtenerFacturasPorGrupo(int grupoId) {
        List<String> facturas = new ArrayList<>();
        String query = """
            SELECT factura_id, titulo, monto, fecha_creacion 
            FROM Facturas 
            WHERE grupo_id = ?
        """;

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, grupoId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String factura = String.format("ID: %d - %s - $%.2f - %s",
                        rs.getInt("factura_id"), rs.getString("titulo"),
                        rs.getDouble("monto"), rs.getDate("fecha_creacion"));
                facturas.add(factura);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener las facturas: " + e.getMessage());
        }

        return facturas;
    }
}
