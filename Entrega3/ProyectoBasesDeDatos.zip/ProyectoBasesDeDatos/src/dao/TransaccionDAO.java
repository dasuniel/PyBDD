package dao;

import java.sql.*;
import java.util.List;
import java.util.ArrayList;


public class TransaccionDAO {
    private final Connection connection;

    public TransaccionDAO(Connection connection) {
        this.connection = connection;
    }

    public void registrarTransaccion(int facturaId, int deudorId, int acreedorId,
                                     double monto, String medioPago, String estado, int aprobadorId) {
        String query = """
            INSERT INTO Transacciones (
                transaccion_id, factura_id, usuario_deudor_id, usuario_acreedor_id, 
                monto, fecha_transaccion, medio_pago, estado, aprobador_id
            ) VALUES (transacciones_seq.NEXTVAL, ?, ?, ?, ?, SYSDATE, ?, ?, ?)
        """;

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, facturaId);
            stmt.setInt(2, deudorId);
            stmt.setInt(3, acreedorId);
            stmt.setDouble(4, monto);
            stmt.setString(5, medioPago);
            stmt.setString(6, estado);
            stmt.setInt(7, aprobadorId);

            stmt.executeUpdate();
            System.out.println("Transacción registrada exitosamente.");
        } catch (SQLException e) {
            System.err.println("Error al registrar la transacción: " + e.getMessage());
        }
    }

    public List<String> obtenerTransaccionesPorEstado(String estado) {
        List<String> transacciones = new ArrayList<>();
        String query = """
            SELECT transaccion_id, monto, fecha_transaccion, medio_pago, estado 
            FROM Transacciones 
            WHERE estado = ?
        """;
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, estado);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String transaccion = String.format("ID: %d - Monto: $%.2f - Fecha: %s - Medio: %s - Estado: %s",
                        rs.getInt("transaccion_id"), rs.getDouble("monto"), rs.getDate("fecha_transaccion"),
                        rs.getString("medio_pago"), rs.getString("estado"));
                transacciones.add(transaccion);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener transacciones por estado: " + e.getMessage());
        }
        return transacciones;
    }

}
