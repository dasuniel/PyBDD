package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {
    private static final String url = "jdbc:oracle:thin:@orion.javeriana.edu.co:1521/LAB";
    private static final String user = "usuario";
    private static final String contrasena = "contra";

    public static Connection getConnection() {
        try {
            // Establecer la conexión
            Connection conexion = DriverManager.getConnection(url, user, contrasena);
            System.out.println("Conexión exitosa a la base de datos");
            return conexion;
        } catch (SQLException e) {
            System.out.println("Error en la conexión: " + e.getMessage());
            return null;
        }
    }
}

