package service;

import dao.GrupoDAO;

import java.sql.Connection;
import java.util.List;

public class GrupoService {
    private GrupoDAO grupoDAO;

    public GrupoService(Connection connection) {
        this.grupoDAO = new GrupoDAO(connection);
    }

    public List<String> obtenerNombresGrupos() {
        return grupoDAO.obtenerNombresGrupos();
    }

    public boolean crearGrupo(String nombre, String descripcion) {
        try {
            grupoDAO.crearGrupo(nombre, descripcion);
            return true;
        } catch (Exception e) {
            System.err.println("Error en crearGrupo: " + e.getMessage());
            return false;
        }
    }
}
