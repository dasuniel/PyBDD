package service;

import dao.FacturaDAO;

import java.sql.Connection;
import java.util.List;

public class FacturaService {
    private FacturaDAO facturaDAO;

    public FacturaService(Connection connection) {
        this.facturaDAO = new FacturaDAO(connection);
    }

    public void crearFactura(int grupoId, int usuarioCreadorId, String titulo, double monto, String imagenUrl) {
        facturaDAO.crearFactura(grupoId, usuarioCreadorId, titulo, monto, imagenUrl);
    }


    public List<String> obtenerFacturasPorGrupo(int grupoId) {
        return facturaDAO.obtenerFacturasPorGrupo(grupoId);
    }
}

