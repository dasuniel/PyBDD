package service;

import dao.TransaccionDAO;

import java.sql.Connection;

public class TransaccionService {
    private TransaccionDAO transaccionDAO;

    public TransaccionService(Connection connection) {
        this.transaccionDAO = new TransaccionDAO(connection);
    }

    public boolean registrarTransaccion(int facturaId, int deudorId, int acreedorId, double monto, String medioPago, String estado, int aprobadorId) {
        try {
            transaccionDAO.registrarTransaccion(facturaId, deudorId, acreedorId, monto, medioPago, estado, aprobadorId);
            return true;
        } catch (Exception e) {
            System.err.println("Error en registrarTransaccion: " + e.getMessage());
            return false;
        }
    }
}

