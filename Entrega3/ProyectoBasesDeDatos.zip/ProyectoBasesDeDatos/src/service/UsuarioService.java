package service;

import dao.UsuarioDAO;
import java.sql.Connection;
import java.util.List;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioService {
    private UsuarioDAO usuarioDAO;

    public UsuarioService(Connection connection) {
        this.usuarioDAO = new UsuarioDAO(connection);
    }

    // Método de login para verificar credenciales
    public boolean login(String correo, String contrasena) {
        return usuarioDAO.verificarCredenciales(correo, contrasena);
    }


    // Método para registrar un nuevo usuario
    public boolean registrarUsuario(String nombre, String correo, String telefono, String paypalId, String contrasena, String imagenUrl) {
        try {
            usuarioDAO.registrarUsuario(nombre, correo, telefono, paypalId, contrasena, imagenUrl);
            return true;
        } catch (Exception e) {
            System.err.println("Error en registrarUsuario: " + e.getMessage());
            return false;
        }
    }

    // Método para obtener la lista de todos los usuarios
    public List<String> obtenerUsuarios() {
        return usuarioDAO.obtenerUsuarios();
    }

    // Método para obtener usuarios por grupo específico
    public List<String> obtenerUsuariosPorGrupo(int grupoId) {
        return usuarioDAO.obtenerUsuariosPorGrupo(grupoId);
    }
}


