package src;

import ui.Menu;
import database.ConexionBD;
import service.GrupoService;
import service.UsuarioService;
import service.FacturaService;
import service.TransaccionService;

import java.sql.Connection;

public class App {
    public static void main(String[] args) {
        // Establecer conexión a la base de datos
        Connection connection = ConexionBD.getConnection();
        if (connection == null) {
            System.err.println("No se pudo conectar a la base de datos.");
            return;
        }

        // Crear instancias de servicios con la conexión
        GrupoService grupoService = new GrupoService(connection);
        UsuarioService usuarioService = new UsuarioService(connection);
        FacturaService facturaService = new FacturaService(connection);
        TransaccionService transaccionService = new TransaccionService(connection);

        // Crear la instancia de Menu con los servicios y mostrar el menú principal
        Menu menu = new Menu(grupoService, facturaService, transaccionService, usuarioService);
        menu.mostrarMenuPrincipal();

        // Cerrar la conexión al terminar
        try {
            connection.close();
            System.out.println("Conexión cerrada.");
        } catch (Exception e) {
            System.err.println("Error al cerrar la conexión: " + e.getMessage());
        }
    }
}

